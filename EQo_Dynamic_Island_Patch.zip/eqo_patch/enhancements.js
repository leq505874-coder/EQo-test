/* EQo — Dynamic Island toggle + hide in-page MP3 test section.
   Load this file AFTER app.js. The native EQ bridge remains unchanged. */
(() => {
  'use strict';
  const start = () => {
    const eq = document.getElementById('eqOn');
    if (!eq || document.getElementById('eqIsland')) return;

    // Hide the whole in-page test card (MP3 player, pink noise and spectrum).
    const testHeading = [...document.querySelectorAll('main h2')]
      .find((el) => el.textContent.trim() === 'Kiểm thử trong app');
    if (testHeading) {
      const testCard = testHeading.closest('section.card');
      if (testCard) testCard.hidden = true;
    }

    const island = document.createElement('button');
    island.id = 'eqIsland';
    island.type = 'button';
    island.className = 'eq-island';
    island.setAttribute('aria-label', 'Bật hoặc tắt EQ');
    island.setAttribute('aria-pressed', String(eq.checked));
    island.innerHTML = '<span class="eq-island-dot" aria-hidden="true"></span><span class="eq-island-label">EQ</span><span class="eq-island-state"></span>';
    document.body.appendChild(island);

    const render = () => {
      island.classList.toggle('is-on', eq.checked);
      island.classList.toggle('is-off', !eq.checked);
      island.setAttribute('aria-pressed', String(eq.checked));
      island.querySelector('.eq-island-state').textContent = eq.checked ? 'ĐANG BẬT' : 'ĐANG TẮT';
    };

    island.addEventListener('click', () => {
      eq.checked = !eq.checked;
      eq.dispatchEvent(new Event('change', { bubbles: true }));
      render();
    });
    eq.addEventListener('change', render);
    render();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
