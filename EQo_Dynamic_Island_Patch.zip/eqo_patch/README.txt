EQo PATCH — Dynamic Island toggle + remove MP3 test UI

WHAT IT DOES
- Adds a floating, rounded capsule at the bottom center of the screen.
- The capsule toggles the existing EQ switch and reflects its ON/OFF state.
- Hides the “Kiểm thử trong app” card, including MP3 upload/player, pink-noise button, and spectrum.
- Does not claim song recognition; song recognition is not implemented in this patch.

INSTALL ON YOUR PHONE (GitHub website)
1. Open your repository: https://github.com/leq505874-coder/QD14_EQ
2. Open the web folder.
3. Upload enhancements.js into web/ (Add file → Upload files → select the file → Commit changes).
4. Open web/index.html and tap the pencil (Edit this file).
5. Find the last script line:
   <script src="app.js"></script>
6. Add this line directly BELOW it:
   <script src="enhancements.js"></script>
7. Commit changes. Wait for GitHub Pages to rebuild, then refresh the site.

IMPORTANT
- Keep the existing app.js script line. The new line must be after app.js.
- This changes the website UI only. System-wide EQ still depends on the Android bridge app and its permissions/support.
